package com.cle.isuite.isuiteadminserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsuiteadminserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
